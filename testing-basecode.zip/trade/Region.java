package trade;

public enum Region {
	
	LONDON, NEWYORK, TOKYO;
}
